*This activity has been created as part of the 42 curriculum by gdika, ahamzall.*

# A-Maze-ing

## Description

**A-Maze-ing** is a Python maze generator and terminal visualizer developed for the 42 curriculum. The program reads a configuration file, constructs a maze using randomized depth-first search (DFS), finds a shortest route between a specified entry and exit, and writes the maze in the hexadecimal format required by the subject.

The project supports two generation modes:

- **Perfect (`PERFECT=True`):** DFS connects each newly visited corridor cell once, giving the generated corridor graph a single route between connected cells.
- **Non-perfect (`PERFECT=False`):** after DFS, the program opens additional connections around dead ends to introduce loops, aiming for a Pac-Man-like layout with alternative routes.

Cells reserved for the recognizable **42** pattern are treated as closed obstacles. A terminal menu lets the user regenerate the maze, show or hide the shortest path, change its colors, and switch among three rendering styles.

The aim was not only to create a maze, but also to practice graph traversal, object-oriented design, data validation, file serialization, terminal rendering, and distributing reusable Python code.

## Instructions

### Requirements

- Python 3.10 or newer.
- Python packages: `pydantic` (configuration validation) and `colorist` (terminal colors).
- For development and packaging: `flake8`, `mypy`, `build`, `setuptools`, and `wheel`.
- A terminal and font that can display the Unicode characters used by the alternative maze styles. The `+`, `-`, and `|` style is the most portable.

### Set up the project

Run these commands from the repository root:

```bash
python3 -m venv venv
source venv/bin/activate
python3 -m pip install pydantic colorist flake8 mypy build setuptools wheel
```

No compilation is needed to run the Python source. To start the application with the default configuration, use:

```bash
python3 a_maze_ing.py config.txt
```

**Current-code note:** the present `a_maze_ing.py` reads `config.txt` directly. Passing `config.txt` above works for the default file, but choosing a different filename on the command line will require reading `sys.argv[1]` in `main`. This should be completed before the final evaluation.

### Interactive menu

| Choice | Action |
| --- | --- |
| `1` | Generate and display a new maze using the existing settings. |
| `2` | Show or hide the shortest solution path. |
| `3` | Change the terminal color combination. |
| `4` | Switch between the available maze styles. |
| `5` | Quit the application. |

The available styles use traditional `+`, `-`, and `|` characters, solid wall characters, and a ladder-like Unicode representation. The maze topology is unchanged when only the visual style or colors change.

### Lint and type checking

```bash
flake8 .
mypy . --warn-return-any --warn-unused-ignores --ignore-missing-imports --disallow-untyped-defs --check-untyped-defs
```

If your repository's `Makefile` defines the corresponding targets, the same operations can be run using `make install`, `make run`, `make debug`, `make lint`, and `make clean`.

## Configuration file

The configuration uses **one `KEY=VALUE` pair per line**. Empty lines and lines beginning with `#` are ignored. Keys are case-insensitive in the parser because they are normalized to lowercase; boolean values in the current parser must be written as `True` or `False`.

Example `config.txt`:

```ini
# Maze dimensions and entry/exit
WIDTH=15
HEIGHT=15
ENTRY=0,0
EXIT=14,14

# Generation settings
PERFECT=False
SEED=42

# Required by the subject; see implementation note below
OUTPUT_FILE=output.txt
```

| Key | Format | Meaning |
| --- | --- | --- |
| `WIDTH` | Positive integer | Number of cells along the first grid coordinate. |
| `HEIGHT` | Positive integer | Number of cells along the second grid coordinate. |
| `ENTRY` | `x,y` | Start-cell coordinates, within the maze. |
| `EXIT` | `x,y` | End-cell coordinates; must differ from `ENTRY`. |
| `PERFECT` | `True` or `False` | Selects the perfect or non-perfect generation mode. |
| `OUTPUT_FILE` | File path | Required by the subject; intended destination of the generated maze. |
| `SEED` | Integer | Initializes the pseudo-random sequence so generation can be reproduced. This project uses it as a configuration value. |

Coordinates in the current `Cell` implementation use `x` for the first grid index (north/south movement) and `y` for the second index (west/east movement). Consequently, `0 <= x < WIDTH` and `0 <= y < HEIGHT`.

**Current-code note:** `GenerateMaze.write_output()` currently writes to the hard-coded path `output.txt`. The `OUTPUT_FILE` key is part of the required configuration format but must be passed through `Data` and the output method before it controls the destination. Until then, the output is written to `output.txt` regardless of that key.

### How the seed works

`random.seed(config.seed)` is called once, before the first maze is created. As the user regenerates, the program consumes the next values in that pseudo-random sequence; it does not reset the seed every time. Repeating a run with the same configuration, code, Python environment, and sequence of menu actions is intended to reproduce the sequence of generated mazes.

In the current version, the style-selection menu also calls `random.choice()`, so changing styles can affect which maze is generated next. Using a separate `random.Random(seed)` instance inside `GenerateMaze` would make generation independent of menu choices.

## Maze generation algorithm

### Randomized depth-first search (recursive backtracking)

The generator starts with cells whose four walls are closed. The `42` pattern is marked before DFS so its reserved cells are not visited as corridors. Starting at the initial cell, DFS:

1. Marks the current cell as visited.
2. Retrieves its neighboring coordinates and shuffles their order.
3. For each unvisited, non-pattern neighbor, connects the two cells and recursively visits that neighbor.
4. Backtracks automatically when there are no more eligible neighbors.

The connections are stored in `Cell.connected_with`. After generation, `save_walls()` converts those connections into open north, east, south, and west walls.

For non-perfect mazes, `non_perfect()` additionally looks for dead ends and attempts to connect them to more neighboring cells. This introduces cycles and alternative routes. The final maze should be checked with the provided analyzer, especially for small dimensions, reachable corridors, dead ends, and the open center required in Pac-Man mode.

### Why we chose DFS

DFS was a good starting point because its recursive flow is relatively easy to follow, it naturally creates winding corridors, and the visited set prevents cycles during the initial perfect-maze generation. It also gave us a clean base that we could extend for the non-perfect mode without writing a separate generation algorithm. Both generation and solving are graph problems, which made DFS and BFS a useful combination to study.

### Finding the shortest path

`bfs(start, end)` uses breadth-first search with `collections.deque`. It explores connected cells in increasing number of steps and records each cell's parent. Once it reaches the exit, it follows the parent links backward and reverses the result. This gives a shortest path by number of moves in the unweighted corridor graph. `find_path()` converts that list of cells into the `N`, `E`, `S`, and `W` directions written to the output file.

## Project structure and classes

```text
├── a_maze_ing.py
├── config.txt
├── LICENSE.md
├── Makefile
├── pyproject.toml
├── README.md
├── requirements.txt
└── srcs
    ├── color.py
    ├── config.py
    ├── gen.py
    └── __init__.py
```

### `Cell` — one position in the maze (`gen.py`)

A `Cell` stores its coordinates, maze dimensions, and the state of its four walls in `walls`. A value of `True` means the wall is closed. The `connected_with` set represents the corridors linking that cell to other cells.

`get_nghb()` returns valid adjacent coordinates; `muret()` opens walls according to the graph connections. The `pattern`, `nghb_south`, `nghb_west`, and `color_plus` attributes support the 42 pattern and its terminal coloring. `print_cor()` provides a readable coordinate string for debugging.

### `GenerateMaze` — maze structure, algorithms and output (`gen.py`)

This class owns the grid as `list_cells`, together with its `width` and `height`. Its main responsibilities are:

| Method | Responsibility |
| --- | --- |
| `save_nghb()` | Create the grid of `Cell` objects. |
| `get_cell(x, y)` | Retrieve a cell from its coordinates. |
| `pattern_42()` | Mark the cells and display flags used for the 42 motif. |
| `dfs(...)` | Build the initial corridor graph using randomized DFS. |
| `non_perfect()` | Attempt to reduce dead ends by adding connections. |
| `remove_cc()` | Clear connections assigned to pattern cells. |
| `save_walls()` | Reflect graph connections in the wall dictionaries. |
| `bfs(start, end)` | Return a shortest path as a list of cells. |
| `find_path(start, end)` | Convert a path into cardinal-direction letters. |
| `cell_to_hex()` / `hex_conv()` | Encode the grid using the required wall bits. |
| `write_output(start, end)` | Write the maze, coordinates and solution to a file. |

`gen.py` contains the reusable generation code and does not depend on the terminal menu, Pydantic or Colorist. The current API exposes the steps individually rather than wrapping them in a single `generate()` method.

### `Data` — parsing and validating configuration (`config.py`)

`Data` is the Pydantic configuration model. Its file-loading and parsing methods read the `KEY=VALUE` input, check required fields, convert numeric values and coordinate pairs, and validate that the entry and exit are distinct and inside the maze. This separates configuration validation from maze generation and rendering.

The current configuration model needs to include and forward `OUTPUT_FILE` to fully support the subject's configurable output path.

### `Grid` — application state and terminal interface (`a_maze_ing.py`)

`Grid` connects the validated configuration to `GenerateMaze`. Its `init()` method builds a fresh maze, marks the pattern, runs the selected generation mode, saves the output and gets the BFS path.

The three `print_maze_*()` methods draw the same grid using different characters. `animate_path()` redraws the maze as more of the solution becomes visible. `menu()` handles regeneration, path visibility, colors, styles and exit. Keeping this class separate means the maze algorithm can be imported without running the interactive application.

### `color_combos()` — terminal colors (`color.py`)

This helper supplies the color values used by the renderers. Colors are passed into the rendering methods instead of being part of the maze's underlying graph. It is a function, not a separate class.

## Output format

Each cell is written as a single hexadecimal digit representing four closed-wall bits:

| Direction | Bit | Value |
| --- | --- | --- |
| North | 0 | `1` |
| East | 1 | `2` |
| South | 2 | `4` |
| West | 3 | `8` |

A closed wall contributes its value; an open wall contributes zero. Cells are written row by row. After a blank line, the file contains the entry coordinates, the exit coordinates and the shortest valid path expressed using `N`, `E`, `S` and `W`.

For example, `F` means all four walls are closed, while `3` means the north and east walls are closed. The current output path is `output.txt`, which is overwritten when a new maze is generated.

## Reusing and packaging the generator

The reusable part is **`gen.py`**, primarily its `Cell` and `GenerateMaze` classes. It can be imported independently of `a_maze_ing.py`:

```python
import random
from src.gen import GenerateMaze

# The current generator uses Python's global random module.
random.seed(42)

maze = GenerateMaze(15, 15)
maze.save_nghb()
maze.pattern_42()

start = maze.get_cell(0, 0)
end = maze.get_cell(14, 14)

maze.dfs(start)
maze.save_walls()

# Access the structure and a shortest solution.
print(start.walls)
print(maze.list_cells)
print(maze.bfs(start, end))
print(maze.find_path(start, end))
```

The example produces the initial DFS maze. A consumer who wants non-perfect generation can additionally call `non_perfect()` and `remove_cc()` before `save_walls()`; those methods should be tested against the required maze constraints.

The distribution is named **`mazegen`**. Because `pyproject.toml` currently declares `py-modules = ["gen"]`, its installed import remains `from gen import GenerateMaze` rather than `from mazegen import GenerateMaze`.

Build the package from the repository root:

```bash
python3 -m pip install build
python3 -m build
```

This creates `dist/mazegen-1.0.0-py3-none-any.whl` and `dist/mazegen-1.0.0.tar.gz` when the package version is `1.0.0`. To install and check the wheel in a virtual environment:

```bash
python3 -m pip install dist/mazegen-1.0.0-py3-none-any.whl
python3 -c "from gen import GenerateMaze; print(GenerateMaze)"
```

Copy the finished `.whl` or `.tar.gz` to the repository root for submission. The repository must also include the build configuration and source so the package can be rebuilt during evaluation. The subject additionally asks for short usage documentation **inside the standalone reusable module**; include a module docstring in `gen.py` as well as this README.

## Team and project management

### Team and contributions

The project was developed together by **gdika** and **ahamzall**. Most of our time was spent working together, sharing ideas, discussing implementation choices and reviewing how the generator, output and visualizer fit together. The work was collaborative rather than divided into two separate projects, and both team members contributed to decisions across the codebase.

Our main areas of focus were different: **ahamzall** spent more time on the algorithmic side, including generation, the maze graph, connections, solving and related debugging; **gdika** spent more time on design and rendering, including the terminal presentation and user experience. These were areas of emphasis, not exclusive ownership: both of us contributed to, discussed and worked on the project as a whole.

### Planning and how it evolved

Our initial plan was to establish the maze data structure, implement the generation algorithm, and then add the visual representation and subject-specific output. As development progressed, generation and presentation needed to be developed together: changes to cells and walls affected the renderer, while the 42 pattern and the non-perfect mode required additional checks in the algorithm.

We also spent time integrating the configuration file, the interactive menu, reproducible randomness, type hints and packaging. Testing against the maze requirements made it necessary to revisit some early assumptions, especially around wall encoding, loops, dead ends and the pattern's placement.

### What worked well and what we would improve

Working together made it easier to review decisions from both the algorithmic and visual perspectives. Testing with different sizes and modes also helped us identify issues that were not apparent from a single successful maze.

If we repeated the project, we would define the interface between generation and rendering earlier, add automated tests for small and large configurations sooner, and separate the generator's random state from the menu. We would also prepare the reusable-package structure and documentation earlier instead of leaving integration and packaging until later in development.

### Tools

We used Python, the terminal, Git, virtual environments and pip for implementation and development. Relevant project tools include Pydantic for configuration validation, Colorist and ANSI escape sequences for the terminal display, `mypy` for type checking, `flake8` for linting, the supplied `maze_analyzer.py` for inspecting generated mazes, and `setuptools`/`build` for distributing the reusable module.

## Resources

- **42 A-Maze-ing subject (v1.5)** — the assignment handout covering configuration, wall encoding, rendering and packaging requirements.
- [Maze generation algorithm: randomized depth-first search](https://en.wikipedia.org/wiki/Maze_generation_algorithm#Randomized_depth-first_search) — recursive backtracking and other maze-generation methods.
- [Python `random` documentation](https://docs.python.org/3/library/random.html) — seeds, shuffling and pseudo-random generation.
- [Python `collections.deque` documentation](https://docs.python.org/3/library/collections.html#collections.deque) — the queue used for BFS.
- [Pydantic documentation](https://pydantic.dev/docs/validation/latest/get-started/) — configuration models and validation.
- [Python Packaging User Guide](https://packaging.python.org/en/latest/tutorials/packaging-projects/) — `pyproject.toml`, wheel files and source distributions.
- [Colorist on PyPI](https://pypi.org/project/colorist/) — the terminal-color library.

### How AI was used

AI was used as a development and learning aid, not as a replacement for understanding the project. It helped us discuss DFS/BFS concepts, reason about seed behavior and regeneration, review specific bugs such as shuffling a temporary list, consider type annotations and Pydantic validation, understand Python packaging, and draft or improve documentation. Suggested changes were reviewed in the context of our code and adapted to the project. The project's algorithmic and visual decisions were made collaboratively by the team.

## Known limitations and final checks

Before final submission, verify that the implementation and this README stay aligned:

- Make the command-line configuration filename functional (`python3 a_maze_ing.py <config-file>`), rather than always reading `config.txt`.
- Add `OUTPUT_FILE` to the validated configuration and pass it to `write_output()` instead of hard-coding `output.txt`.
- Handle maze sizes that cannot fit the 42 pattern without invalid cell indexing, and test the non-perfect mode when a dead end has no eligible neighbor.
- Check perfect and non-perfect outputs with the supplied analyzer, including graph connectivity, wall symmetry, loops, open corners and center, and a valid shortest path.
- Add short import/usage documentation to `gen.py` itself and ensure the package installs in a clean virtual environment.
- Confirm the `LICENSE.md` text explicitly allows reuse and distribution, as required by the subject.

## License

See [LICENSE.md](./LICENSE.md) for the project's reuse and distribution terms.

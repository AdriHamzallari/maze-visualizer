from __future__ import annotations

import random
import sys
from collections import deque
sys.setrecursionlimit(100000000)


"""
A reusable maze generator using randomized depth-first search.

The GenerateMaze class creates a grid of Cell objects and
connects them using DFS. It also supports non-perfect mazes
and shortest-path calculation using BFS.

Example:

    from gen import GenerateMaze

    maze = GenerateMaze(15, 15, seed=42)

    maze.save_nghb()
    maze.pattern_42()

    start = maze.get_cell(0, 0)
    end = maze.get_cell(14, 14)

    maze.dfs(start)
    maze.save_walls()

    # Access the generated maze
    print(maze.list_cells)
    print(start.walls)

    # Access a shortest solution
    path = maze.bfs(start, end)
    print(path)

For non-perfect generation, call non_perfect() and
remove_cc() before save_walls().
"""


class Cell:
    def __init__(self, x: int, y: int,
                 width: int, height: int) -> None:
        self.x: int = x
        self.y: int = y
        self.w: int = width
        self.h: int = height

        self.walls: dict[str, bool] = {
            "N": True,
            "S": True,
            "W": True,
            "E": True
        }

        self.connected_with: set[Cell] = set()

        self.pattern: bool = False
        self.nghb_south: bool = False
        self.nghb_west: bool = False
        self.color_plus: bool = False

    def get_nghb(self) -> list[tuple[int, int]]:
        neighbours: list[tuple[int, int]] = []

        # North
        if self.x > 0:
            neighbours.append((self.x - 1, self.y))

        # South
        if self.x < self.w - 1:
            neighbours.append((self.x + 1, self.y))

        # West
        if self.y > 0:
            neighbours.append((self.x, self.y - 1))

        # East
        if self.y < self.h - 1:
            neighbours.append((self.x, self.y + 1))

        return neighbours

    def muret(self) -> None:
        for cell in self.connected_with:
            if cell.pattern:
                continue

            if self.x == cell.x - 1:
                self.walls["S"] = False

            if self.x == cell.x + 1:
                self.walls["N"] = False

            if self.y == cell.y - 1:
                self.walls["E"] = False

            if self.y == cell.y + 1:
                self.walls["W"] = False

    def print_cor(self) -> str:
        return f"({self.x}, {self.y})"


class GenerateMaze:

    def __init__(self, width: int, height: int, seed: int | None) -> None:
        self.list_cells: list[Cell] = []
        self.width: int = width
        self.height: int = height
        self.seed = seed if seed else None
        random.seed(self.seed)

    def save_nghb(self) -> None:
        for x in range(self.width):
            for y in range(self.height):
                cell: Cell = Cell(
                    x,
                    y,
                    self.width,
                    self.height
                )
                self.list_cells.append(cell)

    def print_cells(self) -> None:
        for cell in self.list_cells:
            print(
                f"{cell.print_cor()} "
                f"has neighbour {cell.get_nghb()}"
            )

    def get_cell(self, x: int, y: int) -> Cell:
        index: int = x * self.height + y
        return self.list_cells[index]

    def remove_cc(self) -> None:
        for cell in self.list_cells:
            if cell.pattern:
                cell.connected_with = set()

    def pattern_42(self) -> None:
        middle: Cell = self.get_cell(int(self.width / 2), int(self.height / 2))
        middle.color_plus = True
        # 4
        cell1: Cell = self.get_cell(middle.x - 2, middle.y - 3)
        cell1.pattern = True
        cell2: Cell = self.get_cell(middle.x - 1, middle.y - 3)
        cell2.pattern = True
        cell3: Cell = self.get_cell(middle.x, middle.y - 3)
        cell3.pattern = True
        cell4: Cell = self.get_cell(middle.x, middle.y - 2)
        cell4.pattern = True
        cell5: Cell = self.get_cell(middle.x, middle.y - 1)
        cell5.pattern = True
        cell6: Cell = self.get_cell(middle.x + 1, middle.y - 1)
        cell6.pattern = True
        cell7: Cell = self.get_cell(middle.x + 2, middle.y - 1)
        cell7.pattern = True
        # 2
        cell8: Cell = self.get_cell(middle.x - 2, middle.y + 1)
        cell8.pattern = True
        cell9: Cell = self.get_cell(middle.x - 2, middle.y + 2)
        cell9.pattern = True
        cella: Cell = self.get_cell(middle.x - 2, middle.y + 3)
        cella.pattern = True
        cellb: Cell = self.get_cell(middle.x - 1, middle.y + 3)
        cellb.pattern = True
        cellc: Cell = self.get_cell(middle.x, middle.y + 1)
        cellc.pattern = True
        celld: Cell = self.get_cell(middle.x, middle.y + 2)
        celld.pattern = True
        celle: Cell = self.get_cell(middle.x, middle.y + 3)
        celle.pattern = True
        cellf: Cell = self.get_cell(middle.x + 1, middle.y + 1)
        cellf.pattern = True
        cellg: Cell = self.get_cell(middle.x + 2, middle.y + 1)
        cellg.pattern = True
        cellh: Cell = self.get_cell(middle.x + 2, middle.y + 2)
        cellh.pattern = True
        celli: Cell = self.get_cell(middle.x + 2, middle.y + 3)
        celli.pattern = True
        # South colouring around pattern
        cellj: Cell = self.get_cell(middle.x + 3, middle.y + 1)
        cellj.nghb_south = True
        cellk: Cell = self.get_cell(middle.x + 3, middle.y + 2)
        cellk.nghb_south = True
        celll: Cell = self.get_cell(middle.x + 3, middle.y + 3)
        celll.nghb_south = True
        cellm: Cell = self.get_cell(middle.x + 3, middle.y - 1)
        cellm.nghb_south = True
        celln: Cell = self.get_cell(middle.x + 1, middle.y - 3)
        celln.nghb_south = True
        cello: Cell = self.get_cell(middle.x + 1, middle.y - 2)
        cello.nghb_south = True
        cellp: Cell = self.get_cell(middle.x + 1, middle.y + 2)
        cellp.nghb_south = True
        cellq: Cell = self.get_cell(middle.x + 1, middle.y + 3)
        cellq.nghb_south = True
        cellr: Cell = self.get_cell(middle.x - 1, middle.y + 1)
        cellr.nghb_south = True
        cells: Cell = self.get_cell(middle.x - 1, middle.y + 2)
        cells.nghb_south = True
        # West colouring
        cellt: Cell = self.get_cell(middle.x, middle.y)
        cellt.nghb_west = True
        cellu: Cell = self.get_cell(middle.x + 1, middle.y)
        cellu.nghb_west = True
        cellv: Cell = self.get_cell(middle.x + 2, middle.y)
        cellv.nghb_west = True
        cellw: Cell = self.get_cell(middle.x + 1, middle.y + 2)
        cellw.nghb_west = True
        cellx: Cell = self.get_cell(middle.x - 1, middle.y - 2)
        cellx.nghb_west = True
        celly: Cell = self.get_cell(middle.x - 2, middle.y - 2)
        celly.nghb_west = True
        cellz: Cell = self.get_cell(middle.x - 2, middle.y + 4)
        cellz.nghb_west = True
        cell11: Cell = self.get_cell(middle.x - 1, middle.y + 4)
        cell11.nghb_west = True
        cell12: Cell = self.get_cell(middle.x, middle.y + 4)
        cell12.nghb_west = True
        cell13: Cell = self.get_cell(middle.x + 2, middle.y + 4)
        cell13.nghb_west = True
        cell14: Cell = self.get_cell(middle.x - 2, middle.y - 4)
        # Plus colouring
        cell15: Cell = self.get_cell(middle.x + 1, middle.y)
        cell15.color_plus = True
        cell16: Cell = self.get_cell(middle.x + 2, middle.y)
        cell16.color_plus = True
        cell17: Cell = self.get_cell(middle.x + 3, middle.y)
        cell17.color_plus = True
        cell18: Cell = self.get_cell(middle.x - 1, middle.y)
        cell18.color_plus = True
        cell19: Cell = self.get_cell(middle.x - 2, middle.y)
        cell19.color_plus = True
        cell20: Cell = self.get_cell(middle.x - 1, middle.y - 4)
        cell20.color_plus = True
        cell21: Cell = self.get_cell(middle.x, middle.y - 4)
        cell21.color_plus = True
        cell22: Cell = self.get_cell(middle.x + 1, middle.y - 4)
        cell22.color_plus = True
        cell23: Cell = self.get_cell(middle.x + 2, middle.y - 2)
        cell23.color_plus = True
        cell24: Cell = self.get_cell(middle.x + 3, middle.y - 2)
        cell24.color_plus = True
        cell25: Cell = self.get_cell(middle.x - 2, middle.y - 4)
        cell25.color_plus = True
        # Avoid unused-variable warning for cell14.
        cell14.nghb_west = cell14.nghb_west

    def dfs(self, ran_cell: Cell, visited_s: set[Cell] | None = None) -> None:
        if visited_s is None:
            visited_s = set()
        visited_s.add(ran_cell)
        neighbours: list[tuple[int, int]] = (ran_cell.get_nghb())
        random.shuffle(neighbours)
        for x, y in neighbours:
            curr_cell: Cell = self.get_cell(x, y)
            if (curr_cell not in visited_s
                    and not curr_cell.pattern):
                ran_cell.connected_with.add(curr_cell)
                curr_cell.connected_with.add(ran_cell)

                self.dfs(curr_cell, visited_s)

    def save_walls(self) -> None:
        for cell in self.list_cells:
            cell.muret()

    def bfs(self, start: Cell, end: Cell) -> list[Cell]:
        queue: deque[Cell] = deque([start])
        visited: set[Cell] = {start}
        parent: dict[Cell, Cell | None] = {start: None}

        while queue:
            curr_cell: Cell = queue.popleft()

            if curr_cell == end:
                break

            for cell in curr_cell.connected_with:
                if cell in visited:
                    continue

                visited.add(cell)
                parent[cell] = curr_cell
                queue.append(cell)

        if end not in visited:
            return []

        path: list[Cell] = []

        current: Cell | None = end

        while current is not None:
            path.append(current)
            current = parent[current]

        path.reverse()

        return path

    def cell_to_hex(self, cell: Cell) -> str:
        value: int = 0

        if cell.walls["N"]:
            value += 1

        if cell.walls["E"]:
            value += 2

        if cell.walls["S"]:
            value += 4

        if cell.walls["W"]:
            value += 8

        return format(value, "X")

    def hex_conv(self) -> str:
        output: str = ""

        for x in range(self.width):
            for y in range(self.height):
                cell: Cell = self.get_cell(x, y)
                output += self.cell_to_hex(cell)

            output += "\n"

        return output + "\n"

    def find_path(self, start: Cell, end: Cell) -> str:
        bfs_path: list[Cell] = self.bfs(start, end)
        path: str = ""

        for i in range(len(bfs_path) - 1):
            current: Cell = bfs_path[i]
            next_cell: Cell = bfs_path[i + 1]

            if current.x == next_cell.x - 1:
                path += "S"

            elif current.x == next_cell.x + 1:
                path += "N"

            elif current.y == next_cell.y - 1:
                path += "E"

            elif current.y == next_cell.y + 1:
                path += "W"

        return path

    def write_output(self, start: Cell, end: Cell) -> None:
        output: str = self.hex_conv()

        output += f"{start.x},{start.y}\n"
        output += f"{end.x},{end.y}\n"
        output += self.find_path(start, end) + "\n"

        with open("output.txt", "w") as file:
            file.write(output)

    def non_perfect(self) -> None:
        dead_end_cells: list[Cell] = []

        for cell in self.list_cells:
            if (len(cell.connected_with) == 1 and not cell.pattern):
                dead_end_cells.append(cell)

        for dead_cell in dead_end_cells:
            connected_tuples = {(c.x, c.y) for c in dead_cell.connected_with}
            neighbours = list(set(dead_cell.get_nghb()) - connected_tuples)
            random.shuffle(neighbours)
            x, y = neighbours[0]
            neighbour: Cell = self.get_cell(x, y)
            dead_cell.connected_with.add(neighbour)
            neighbour.connected_with.add(dead_cell)

        if len(dead_end_cells) != 0:
            self.non_perfect()
